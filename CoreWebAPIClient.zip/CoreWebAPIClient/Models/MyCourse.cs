﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreWebAPIClient.Models
{
    public class MyCourse
    {
        public int course_id { get; set; }
        public string course_name { get; set; }
    }
}
